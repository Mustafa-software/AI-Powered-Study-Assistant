// Function to update the current time
function updateCurrentTime() {
    const currentTimeElement = document.getElementById('currentTime');
    const currentTime = new Date();
    let hours = currentTime.getHours();
    const minutes = currentTime.getMinutes().toString().padStart(2, '0');
    const seconds = currentTime.getSeconds().toString().padStart(2, '0');
    
    const ampm = hours >= 12 ? 'PM' : 'AM'; // تحديد AM أو PM
    hours = hours % 12; // تحويل إلى 12 ساعة
    hours = hours ? hours : 12; // الساعة 0 تصبح 12

    currentTimeElement.textContent = `Time: ${hours}:${minutes}:${seconds} ${ampm}`;
}

// Update the current time every second
setInterval(updateCurrentTime, 1000);

// Update the current time immediately on page load
updateCurrentTime();

    // Function to add a  reminder
function addReminder() {
    const TaskName = document.getElementById('taskName').value;
    const reminderTime = document.getElementById('reminderTime').value;

    // تحويل الوقت إلى صيغة 12 ساعة
    const reminderDate = new Date(reminderTime);
    const hours = reminderDate.getHours();
    const minutes = reminderDate.getMinutes();
    const year = reminderDate.getFullYear();
    const month = (reminderDate.getMonth() + 1).toString().padStart(2, '0'); // إضافة 1 لأن الأشهر تبدأ من 0
    const day = reminderDate.getDate().toString().padStart(2, '0');
    
    const hours12 = hours % 12 || 12; // تحويل إلى 12 ساعة
    const ampm = hours >= 12 ? 'PM' : 'AM'; // تحديد AM أو PM
    const formattedTime = `${year}-${month}-${day} ${hours12}:${minutes.toString().padStart(2, '0')} ${ampm}`; // تنسيق الوقت

    // Create reminder item
    const reminderItem = document.createElement('li');
    reminderItem.classList.add('reminder-item');

    // Display the reminder information
    reminderItem.innerHTML = `
        <div>${TaskName} - ${formattedTime}</div>
        <button class="delete-btn" onclick="deleteReminder(this)">Delete</button>
    `;

    // Add the reminder to the list
    const remindersList = document.getElementById('reminders');
    remindersList.appendChild(reminderItem);

    // Set up the alarm for the reminder
    setupAlarm(reminderTime);

    // Clear input fields
    document.getElementById('taskName').value = '';
    document.getElementById('reminderTime').value = '';
}
        // Function to delete a reminder
        function deleteReminder(buttonElement) {
            const reminderItem = buttonElement.parentElement;
            const remindersList = document.getElementById('reminders');
            remindersList.removeChild(reminderItem);
        }

        function setupAlarm(reminderTime) {
            const currentTime = new Date();
            const reminderDate = new Date(reminderTime);
            
            // حساب الفرق في الوقت بالمللي ثانية
            const timeDifference = reminderDate.getTime() - currentTime.getTime();
            
            // Set up the alarm
            if (timeDifference > 0) {
                setTimeout(() => {
                    const alarmSound = document.getElementById('alarmSound');
                    if (alarmSound) {
                        alarmSound.play().catch(error => {
                            console.error("Error playing sound:", error);
                        });
        
                        // تنبيه بعد 10 ثواني من تشغيل الصوت
                        setTimeout(() => {
                            const alertResponse = alert("Reminder: It's time for your task!");
                            // إيقاف الصوت عند الضغط على OK
                            alarmSound.pause();
                            alarmSound.currentTime = 0; // إعادة الصوت إلى البداية
                        }, 1000); // 10 ثواني
                    } else {
                        console.error("Alarm sound element not found.");
                    }
                }, timeDifference);
            } else {
                console.error("Reminder time is in the past.");
            }
        }
        
        